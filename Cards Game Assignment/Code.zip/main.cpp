#include "Match.h"
#include "Deck.h"
#include "Player.h"



int main() {
	Match game;
	
	//Method to begin the match
	game.matchStart();
	



	

}
//Header file to store headers for a more clean and organized code 

#pragma once
#include <iostream>
#include <iterator>
#include <cstdlib>
#include <time.h>


using namespace std;